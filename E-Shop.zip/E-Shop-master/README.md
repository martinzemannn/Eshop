# E-Shop
E-Shop using (PHP, MYSQL, JavaScript,AJAX,HTML)

This is a free project since some parts were gathered from open sources
This is an E-Shop Website with:
      1- User:  
            1) Login 
            2) Logout
            3) signup
            4) Edit Profile
            5) View Bought History
      2- Shop:
            1) View Products
            2) View Products Details
            3) Add to Checkout
            4) Buy Products
            
Download & Install:
      1- Clone Repo : git clone https://github.com/MoAgamia/E-Shop.git
      2- Open DBconnect.php Edit connection to your database
      3- Open DB.sql add tables to your database
      4- Run Homepage.php 
